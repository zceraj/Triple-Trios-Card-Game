package tripletrios.strategy;

public class MockModelStrategyFour {
}
