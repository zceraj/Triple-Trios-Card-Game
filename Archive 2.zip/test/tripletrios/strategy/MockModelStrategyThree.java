package tripletrios.strategy;

public class MockModelStrategyThree {
}
