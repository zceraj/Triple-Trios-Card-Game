package tripletrios.strategy;

public class MockModelStrategyTwo {
}
