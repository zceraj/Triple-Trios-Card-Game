package cs3500.tripletrios.strategy;

import cs3500.tripletrios.model.IPlayer;

public class StrategyThree extends AbstractStrategy implements StrategyInterface {
 

  @Override
  public Moves getBestMove(IPlayer computerPlayer) {
    return null;
  }

   /*Strat 3
//  * choose cards less likley t be flipped in general
//  * consider each position for each card, for each direction
//  * figuring out how many of the opponents card can flip them
//  * card and position combination with the smallest chance of being flipped
//   */
//

}
