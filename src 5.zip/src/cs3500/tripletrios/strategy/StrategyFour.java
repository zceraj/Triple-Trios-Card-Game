package cs3500.tripletrios.strategy;

public class StrategyFour {


//  /*  Strat 4
//  *moves that leaves opponent in situation with no good moves
//  * minimizes the maxiumum move the opponent can make
//  * calculate best move and opponenet can make -> must make soem guess to
//  *     what strategy the opponent is using
//   */
//

}
