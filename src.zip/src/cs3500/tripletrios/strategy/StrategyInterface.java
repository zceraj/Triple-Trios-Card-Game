package cs3500.tripletrios.strategy;

public interface StrategyInterface {
}
